// Voice Command for Women Safety
// Listens for keywords: "danger", "SOS", "emergency"

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

if (!SpeechRecognition) {
    console.error("Speech Recognition is not supported in this browser.");
} else {
    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.lang = 'en-US';
    recognition.interimResults = false;

    recognition.onstart = () => {
        console.log("Voice recognition started. Listening for 'danger', 'SOS', or 'emergency'...");
    };

    recognition.onerror = (event) => {
        console.error("Speech recognition error:", event.error);
        if (event.error === 'not-allowed') {
            alert("Microphone access is required for voice commands. Please enable it in your browser settings.");
        }
        // Restart recognition on error if it's not a fatal error
        if (event.error !== 'not-allowed') {
            setTimeout(() => recognition.start(), 1000);
        }
    };

    recognition.onend = () => {
        console.log("Voice recognition ended. Restarting...");
        recognition.start();
    };

    let isProcessing = false;

    recognition.onresult = (event) => {
        if (isProcessing) return;

        const transcript = event.results[event.results.length - 1][0].transcript.toLowerCase().trim();
        console.log("Detected speech:", transcript);

        if (transcript.includes("danger") || transcript.includes("sos") || transcript.includes("emergency")) {
            console.log("Emergency keyword detected! Sending alerts...");
            isProcessing = true;
            sendEmergencyAlert().then(() => {
                // Reset flag after 10 seconds to allow for another alert if needed
                setTimeout(() => { isProcessing = false; }, 10000);
            });
        }
    };

    // Start recognition
    try {
        recognition.start();
    } catch (e) {
        console.error("Error starting speech recognition:", e);
    }
}

async function sendEmergencyAlert() {
    // Try to get values from page elements first (if on page_three.html)
    let n1 = document.getElementById('number1')?.value;
    let m1 = document.getElementById('textMessage1')?.value;
    let n2 = document.getElementById('number2')?.value;
    let m2 = document.getElementById('textMessage2')?.value;
    let n3 = document.getElementById('number3')?.value;
    let m3 = document.getElementById('textMessage3')?.value;

    // If on other pages, get from localStorage
    if (!n1) n1 = localStorage.getItem('emergencyNumber1');
    if (!m1) m1 = localStorage.getItem('emergencyMessage1');
    if (!n2) n2 = localStorage.getItem('emergencyNumber2');
    if (!m2) m2 = localStorage.getItem('emergencyMessage2');
    if (!n3) n3 = localStorage.getItem('emergencyNumber3');
    if (!m3) m3 = localStorage.getItem('emergencyMessage3');

    // Default values if nothing is found
    n1 = n1 || "8884014669";
    m1 = m1 || "Please save me. I am in Danger";
    n2 = n2 || "9825042341";
    m2 = m2 || "Please save me. I am in Danger";
    n3 = n3 || "7698225243";
    m3 = m3 || "Please save me. I am in Danger";

    const data = [
        {
            number: n1,
            message: m1,
            url: 'includes/call1.php',
            buttonName: 'SubmitButton1',
            numKey: 'userMobile1',
            msgKey: 'userMessage1'
        },
        {
            number: n2,
            message: m2,
            url: 'includes/call2.php',
            buttonName: 'SubmitButton2',
            numKey: 'userMobile2',
            msgKey: 'userMessage2'
        },
        {
            number: n3,
            message: m3,
            url: 'includes/call3.php',
            buttonName: 'SubmitButton3',
            numKey: 'userMobile3',
            msgKey: 'userMessage3'
        }
    ];

    for (const contact of data) {
        if (contact.number && contact.message) {
            console.log(`Sending alert to ${contact.number}...`);
            const formData = new FormData();
            formData.append(contact.buttonName, 'true'); 
            formData.append(contact.numKey, contact.number);
            formData.append(contact.msgKey, contact.message);

            try {
                const response = await fetch(contact.url, {
                    method: 'POST',
                    body: formData
                });
                const result = await response.text();
                console.log(`Alert sent to ${contact.number}:`, result);
            } catch (error) {
                console.error(`Error sending alert to ${contact.number}:`, error);
            }
        }
    }
    
    // Play the siren sound if available
    const siren = new Audio('images/siren.mp3');
    siren.play().catch(e => console.error("Error playing siren:", e));
    
    alert("Emergency alert sent to all contacts!");
}

// Function to save current form data to localStorage
function saveEmergencyContacts() {
    const n1 = document.getElementById('number1')?.value;
    const m1 = document.getElementById('textMessage1')?.value;
    const n2 = document.getElementById('number2')?.value;
    const m2 = document.getElementById('textMessage2')?.value;
    const n3 = document.getElementById('number3')?.value;
    const m3 = document.getElementById('textMessage3')?.value;

    if (n1) localStorage.setItem('emergencyNumber1', n1);
    if (m1) localStorage.setItem('emergencyMessage1', m1);
    if (n2) localStorage.setItem('emergencyNumber2', n2);
    if (m2) localStorage.setItem('emergencyMessage2', m2);
    if (n3) localStorage.setItem('emergencyNumber3', n3);
    if (m3) localStorage.setItem('emergencyMessage3', m3);
}

// Add event listeners if elements are present
window.addEventListener('DOMContentLoaded', () => {
    ['number1', 'textMessage1', 'number2', 'textMessage2', 'number3', 'textMessage3'].forEach(id => {
        document.getElementById(id)?.addEventListener('change', saveEmergencyContacts);
    });
    // Initial save
    saveEmergencyContacts();
});
