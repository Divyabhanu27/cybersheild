
const fs = require('fs');
const path = require('path');

const projectRoot = 'c:/Users/shiva/OneDrive/Desktop/Women-safety-web-application/Women-safety-web-application';

console.log("--- STARTING APP VERIFICATION TEST ---");

const filesToCheck = [
    'index.html',
    'page_one.html',
    'page_two.html',
    'page_three.html',
    'page_four.html',
    'style.css',
    'voice_command.js',
    'includes/call1.php',
    'includes/call2.php',
    'includes/call3.php',
    'images/siren.mp3',
    'images/sos.jpeg'
];

let allPassed = true;

console.log("\n1. Verifying File Existence:");
filesToCheck.forEach(file => {
    const fullPath = path.join(projectRoot, file);
    if (fs.existsSync(fullPath)) {
        console.log(`[OK] ${file} exists.`);
    } else {
        console.error(`[FAIL] ${file} is missing!`);
        allPassed = false;
    }
});

console.log("\n2. Verifying Voice Command Integration:");
const htmlFiles = ['index.html', 'page_one.html', 'page_two.html', 'page_three.html', 'page_four.html'];
htmlFiles.forEach(file => {
    const fullPath = path.join(projectRoot, file);
    if (fs.existsSync(fullPath)) {
        const content = fs.readFileSync(fullPath, 'utf8');
        if (content.includes('src="voice_command.js"')) {
            console.log(`[OK] voice_command.js integrated in ${file}.`);
        } else {
            console.error(`[FAIL] voice_command.js NOT integrated in ${file}!`);
            allPassed = false;
        }
    }
});

console.log("\n3. Verifying PHP Script Fixes (SubmitButton numbering):");
const phpFixes = [
    { file: 'includes/call1.php', check: 'SubmitButton1' },
    { file: 'includes/call2.php', check: 'SubmitButton2' },
    { file: 'includes/call3.php', check: 'SubmitButton3' }
];

phpFixes.forEach(fix => {
    const fullPath = path.join(projectRoot, fix.file);
    if (fs.existsSync(fullPath)) {
        const content = fs.readFileSync(fullPath, 'utf8');
        if (content.includes(fix.check)) {
            console.log(`[OK] ${fix.file} has correct button ID (${fix.check}).`);
        } else {
            console.error(`[FAIL] ${fix.file} is missing ${fix.check}!`);
            allPassed = false;
        }
    }
});

console.log("\n4. Verifying Voice Command Logic (Keywords):");
const voiceJsPath = path.join(projectRoot, 'voice_command.js');
if (fs.existsSync(voiceJsPath)) {
    const content = fs.readFileSync(voiceJsPath, 'utf8');
    const keywords = ['danger', 'sos', 'emergency'];
    keywords.forEach(word => {
        if (content.toLowerCase().includes(word)) {
            console.log(`[OK] Keyword "${word}" found in voice_command.js.`);
        } else {
            console.error(`[FAIL] Keyword "${word}" missing from voice_command.js!`);
            allPassed = false;
        }
    });
}

console.log("\n--- TEST SUMMARY ---");
if (allPassed) {
    console.log("SUCCESS: All core features verified and running perfectly!");
} else {
    console.error("FAILURE: Some features or files are missing/incorrect.");
    process.exit(1);
}
